;

<?php $__env->startSection('contenido'); ?>
    <a href="articulos/create" class="btn btn-primary">CREAR</a>    

    <table class="table table-dark table-striped mt-4">
        <thead>
            <tr>
                <th scope = "col">ID</th>
                <th scope = "col">Codigo</th>
                <th scope = "col">Descripcion</th>
                <th scope = "col">Cantidad</th>
                <th scope = "col">Precio</th>
                <th scope = "col">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($articulo->id); ?></td>
                    <td><?php echo e($articulo->Codigo); ?></td>
                    <td><?php echo e($articulo->Descripcion); ?></td>
                    <td><?php echo e($articulo->Cantidad); ?></td>
                    <td><?php echo e($articulo->Precio); ?></td>
                    <td>
                        <a href="/articulos/<?php echo e($articulo->id); ?>/edit" class="btn btn-info">Editar</a>
                        <button class="btn btn-danger">Borrar</button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\lara8Crud\resources\views/articulo/index.blade.php ENDPATH**/ ?>